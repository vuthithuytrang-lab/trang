// Cửa sổ điều khiển: kiểm tra Last crawl từng URL, bỏ qua URL Google đã đọc sau mốc giờ,
// ép phần còn lại đến khi thành công. Logic bấm/đọc giữ nguyên skill gốc (mac/request.sh, mac/inspect.sh):
// chỉ tính OK khi thấy "Testing if live URL" rồi hộp thoại "Indexing requested" MỚI.
// Theo skill gốc: lần đầu không được thì thử lại tối đa 20 lần; mỗi lần chờ 60s (bị rejected: 15s)
const MAX_RETRY = 20, WAIT_RETRY = 60, WAIT_REJECTED = 15;
const $ = (id) => document.getElementById(id);

// ---------- Đồng hồ không bị làm chậm ----------
const timer = new Worker('timer.js');
const waits = {}; let waitId = 0;
timer.onmessage = (e) => { waits[e.data](); delete waits[e.data]; };
const sleep = (sec) => new Promise((r) => { const id = ++waitId; waits[id] = r; timer.postMessage({ id, ms: sec * 1000 }); });

// ---------- Nhật ký + kết quả ----------
let stopFlag = false, results = {};
function log(s) {
  const d = new Date(), t = d.toLocaleTimeString('vi-VN', { hour12: false });
  const box = $('nhatky');
  box.textContent += `[${t}] ${s}\n`;
  box.scrollTop = box.scrollHeight;
}
function status(s) { $('trangthai').textContent = s; }
async function saveResult(u, kq, note) {
  results[u] = { kq, note, moc: $('moc').value };
  await chrome.storage.local.set({ results });
  showCount();
}
function showCount() {
  const v = Object.values(results), c = (k) => v.filter((x) => x.kq === k).length;
  $('dem').textContent = `Đã đọc: ${c('DA-DOC')} · Ép OK: ${c('OK')} · Chưa được: ${c('FAIL')} · Bỏ qua: ${c('SKIP')}`;
}

// ---------- Các hàm chạy bên trong tab GSC ----------
// Viết dạng `tên: function` (không viết tắt kiểu method) vì Chrome chép nguyên văn hàm sang tab để chạy.
const BASE = 'https://search.google.com';
const P = {
  // Chặn Chrome tự dịch trang (bản dịch làm hỏng việc nhận diện chữ tiếng Anh)
  notranslate: function () {
    document.documentElement.setAttribute('translate', 'no');
    document.documentElement.classList.add('notranslate');
    if (!document.querySelector('meta[name=google][content=notranslate]')) {
      const m = document.createElement('meta'); m.name = 'google'; m.content = 'notranslate'; document.head.appendChild(m);
    }
    return document.documentElement.classList.contains('translated-ltr') || document.documentElement.classList.contains('translated-rtl') ? 'TRANSLATED' : 'OK';
  },
  fill: async function (u) {
    const shown = (x) => x.getClientRects().length > 0;
    const label = (x) => [x.getAttribute('aria-label'), x.getAttribute('placeholder'), x.getAttribute('title')].join(' ');
    const find = () => {
      const ins = [...document.querySelectorAll('input')].filter((x) => shown(x) && !/hidden|checkbox|radio/i.test(x.type));
      return ins.find((x) => /Inspect any URL|Kiểm tra mọi URL/i.test(label(x))) || ins.find((x) => /Inspect|URL/i.test(label(x)));
    };
    let i = find();
    if (!i) {
      // cửa sổ hẹp: ô tìm kiếm thu thành kính lúp → bấm để mở ra
      const b = [...document.querySelectorAll('[role=button],button')].find((x) => /Inspect|Search/i.test(label(x)) && shown(x));
      if (b) { b.click(); await new Promise((r) => setTimeout(r, 1000)); i = find(); }
    }
    if (!i) {
      // ghi lại các ô đang có để sửa tiếp
      return 'NOINPUT ' + [...document.querySelectorAll('input')].slice(0, 8)
        .map((x) => `[${x.type}|${shown(x) ? 'hiện' : 'ẩn'}|${label(x).trim()}]`).join(' ');
    }
    i.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(i, u);
    i.dispatchEvent(new Event('input', { bubbles: true }));
    i.dispatchEvent(new Event('change', { bubbles: true }));
    const o = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true };
    ['keydown', 'keypress', 'keyup'].forEach((t) => i.dispatchEvent(new KeyboardEvent(t, o)));
    return 1;
  },
  read: function (u) {
    const t = document.body.innerText;
    if (!location.pathname.includes('inspect') || !t.includes(u) || /Retrieving data/i.test(t) ||
        !/URL is (not )?on Google|unknown to Google|not in (the current )?property/i.test(t)) return 'loading';
    const m = [...document.querySelectorAll('*')].filter((e) => e.children.length === 0 && e.textContent.trim() === 'Last crawl');
    const lc = m.map((x) => x.parentElement.parentElement.textContent.replace('Last crawl', '').replace(/Crawled as.*/, '').trim()).join(' || ');
    const st = (t.match(/URL is (not )?on Google|URL is unknown to Google|not in (the current )?property/i) || [''])[0];
    return { st, lc, href: location.href };
  },
  ready: function (u) {
    const t = document.body.innerText;
    if (/not in (the current )?property/i.test(t)) return 'NOTPROP';
    if (!location.pathname.includes('inspect') || !t.includes(u) || /Retrieving data/i.test(t)) return 'loading';
    return /REQUEST INDEXING/i.test(t) ? 'READY' : 'loading';
  },
  click: function (src) {
    const lbl = new RegExp(src, 'i');
    const bs = [...document.querySelectorAll('[role=button]')].filter((e) => lbl.test((e.innerText || '').trim()) && e.offsetParent);
    bs.forEach((b) => {
      const r = b.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: window, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2, button: 0 };
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach((t) => b.dispatchEvent(new (t.startsWith('pointer') ? PointerEvent : MouseEvent)(t, o)));
    });
    return bs.length;
  },
  dismiss: function () {
    const bs = [...document.querySelectorAll('button')].filter((b) => /^Dismiss$/i.test((b.innerText || '').trim()) && b.offsetParent);
    bs.forEach((b) => b.click());
    return bs.length;
  },
  vis: function () {
    return [...document.querySelectorAll('*')].filter((e) => e.children.length === 0 && /Indexing requested/.test(e.textContent) && e.offsetParent).length;
  },
  watch: function () {
    const t = document.body.innerText;
    if (/Indexing request rejected/i.test(t)) return 'rejected';
    const m = t.match(/Quota exceeded|Something went wrong|not a robot|recaptcha/i);
    if (m) return m[0];
    const vis = [...document.querySelectorAll('*')].filter((e) => e.children.length === 0 && /Indexing requested/.test(e.textContent) && e.offsetParent).length;
    if (vis > 0 && /added to a priority crawl queue/i.test(t)) return 'requested';
    return /Testing if live URL/i.test(t) ? 'testing' : 'none';
  },
};

// ---------- Điều khiển tab ----------
let tabId = null, rid = '', lastErr = '';
async function findTab(domain) {
  // phóng to cửa sổ GSC để ô "Kiểm tra URL" hiện đầy đủ
  const tabs = await chrome.tabs.query({ url: BASE + '/search-console*' });
  const t = tabs.find((x) => x.url.includes(domain) && /[?&]resource_id=/.test(x.url));
  if (!t) throw new Error(`Không thấy tab Search Console của ${domain}. Hãy mở trang Tổng quan của ${domain} trong Chrome này.`);
  tabId = t.id;
  rid = t.url.match(/[?&]resource_id=([^&#]*)/)[1];
  await chrome.tabs.update(tabId, { active: true });
  await chrome.windows.update(t.windowId, { state: 'maximized' }).catch(() => {});
}
async function run(fn, ...args) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: fn, args });
    return r ? r.result : null;
  } catch (e) {
    if (/No tab with id/i.test(e.message)) throw new Error('Tab Search Console đã bị đóng. Hãy mở lại rồi bấm Bắt đầu.');
    lastErr = e.message;
    return null; // tab đang tải trang
  }
}
async function nav(url) {
  await chrome.tabs.update(tabId, { url });
  for (let i = 0; i < 30; i++) {
    await sleep(1);
    const t = await chrome.tabs.get(tabId);
    if (t.status === 'complete') break;
  }
}
let warnedTranslate = false;
async function home() {
  await nav(`${BASE}/search-console?resource_id=${rid}&hl=en`);
  await sleep(1);
  if ((await run(P.notranslate)) === 'TRANSLATED' && !warnedTranslate) {
    warnedTranslate = true;
    log('⚠️ Chrome đang tự dịch trang GSC — hãy tắt dịch cho trang này (xem hướng dẫn của Claude)');
  }
}
const CLOSE = '^(Dismiss|GOT IT)$';
async function fillOrLog(u) {
  lastErr = '';
  const f = await run(P.fill, u);
  if (f !== 1) log(`  Chưa thấy ô Kiểm tra URL, đang thử lại... ${f || ('Chrome báo: ' + (lastErr || 'không rõ'))}`);
}

// ---------- Đọc Last crawl ----------
async function inspect(u) {
  await home(); await sleep(6);
  let r = null;
  for (let k = 0; k < 3 && !(r && r.st !== undefined); k++) {
    await fillOrLog(u);
    for (let i = 0; i < 15; i++) { await sleep(3); r = await run(P.read, u); if (r && r.st !== undefined) break; }
    if (!(r && r.st !== undefined)) await sleep(3);
  }
  if (!(r && r.st !== undefined)) return null;
  // tải lại đúng trang kết quả cho sạch rồi đọc lại
  await nav(r.href); await sleep(5);
  for (let i = 0; i < 20; i++) { r = await run(P.read, u); if (r && r.st !== undefined) return r; await sleep(3); }
  return null;
}

// "Oct 30, 2026, 9:15:23 PM" → Date (giờ máy, cũng là giờ GSC hiển thị); không đọc được → null
const MON = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
function parseCrawl(s) {
  if (!s) return null;
  s = s.split(' || ')[0].replace(/[  ]/g, ' ');
  const m = s.match(/([A-Z][a-z]{2}) (\d{1,2}), (\d{4}),? (\d{1,2}):(\d{2})(?::(\d{2}))? ?([AP]M)/);
  if (!m || !(m[1] in MON)) return null;
  let h = +m[4] % 12; if (m[7] === 'PM') h += 12;
  return new Date(+m[3], MON[m[1]], +m[2], h, +m[5], +(m[6] || 0));
}
const fmt = (d) => d.toLocaleString('vi-VN', { hour12: false, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

// Google đã đọc sau mốc chưa? → 'NOTPROP' | chữ giờ đọc | null (chưa)
async function freshSince(u, cut) {
  const r = await inspect(u);
  if (!r) { log('  Không đọc được trang kiểm tra — coi như chưa đọc'); return null; }
  if (/not in/i.test(r.st)) return 'NOTPROP';
  const d = parseCrawl(r.lc);
  if (d && d >= cut) return fmt(d);
  log(`  Last crawl: ${r.lc || '(không có)'}`);
  return null;
}

// ---------- Một lần Request indexing ----------
// → OK | SKIP | REJECTED | QUOTA | ROBOT | FAIL:<lý do>
async function request(u) {
  await home(); await sleep(7);
  let st = '';
  for (let k = 0; k < 3; k++) {
    await run(P.click, CLOSE); await sleep(1);
    await fillOrLog(u);
    for (let i = 0; i < 15; i++) { await sleep(3); st = await run(P.ready, u); if (st === 'READY' || st === 'NOTPROP') break; }
    if (st === 'READY' || st === 'NOTPROP') break;
  }
  if (st === 'NOTPROP') return 'SKIP';
  if (st !== 'READY') return 'FAIL:không mở được trang kiểm tra';
  await run(P.click, CLOSE); await sleep(1);
  if ((await run(P.vis)) !== 0) return 'FAIL:hộp thoại cũ chưa đóng';
  await run(P.click, '^REQUEST INDEXING$');
  let seen = false, r = 'none';
  for (let i = 0; i < 200; i++) {
    await sleep(3);
    r = (await run(P.watch)) || 'none';
    if (r === 'testing') seen = true;
    if (r !== 'none' && r !== 'testing') break;
  }
  let res;
  if (r === 'requested' && seen) res = 'OK';
  else if (r === 'rejected') { await run(P.dismiss); res = 'REJECTED'; }
  else if (/Quota/i.test(r)) res = 'QUOTA';
  else if (/robot|recaptcha/i.test(r)) res = 'ROBOT';
  else res = `FAIL:${r} (testing_seen=${seen})`;
  await run(P.click, CLOSE);
  return res;
}

// ---------- Chạy cả danh sách ----------
async function main() {
  const domain = $('domain').value.trim();
  const cut = new Date($('moc').value);
  if (isNaN(cut)) throw new Error('Chưa nhập giờ publish.');
  const urls = [...new Set($('urls').value.split(/\s+/).filter((x) => /^https?:\/\//.test(x)))];
  await findTab(domain);
  log(`Bắt đầu: ${urls.length} link, mốc ${fmt(cut)}`);

  // Link đã xong ở lần chạy trước (cùng mốc giờ) thì không làm lại
  const done = (u) => results[u] && results[u].moc === $('moc').value && ['OK', 'DA-DOC', 'SKIP'].includes(results[u].kq);

  // Từng link: kiểm tra Last crawl → cần ép thì ép luôn (thử lại tối đa 20 lần) → sang link sau
  let quotaStop = false;
  for (const [i, u] of urls.entries()) {
    if (stopFlag) return;
    const tag = `[${i + 1}/${urls.length}]`;
    if (done(u)) { log(`${tag} đã xong từ trước: ${u}`); continue; }
    status(`${tag} kiểm tra Google đã đọc chưa`);
    const f = await freshSince(u, cut);
    if (f === 'NOTPROP') { await saveResult(u, 'SKIP', 'không thuộc property'); log(`${tag} BỎ QUA (không thuộc website): ${u}`); continue; }
    if (f) { await saveResult(u, 'DA-DOC', `Google đọc lúc ${f}`); log(`${tag} ĐÃ ĐỌC lúc ${f}: ${u}`); continue; }
    if (quotaStop) { await saveResult(u, 'SKIP', 'cần ép nhưng hết lượt ép trong ngày — chạy lại hôm sau'); log(`${tag} CẦN ÉP nhưng đã hết lượt ép: ${u}`); continue; }
    log(`${tag} CẦN ÉP — đang ép: ${u}`);
    let n = 0, r = '';
    while (!stopFlag) {
      status(`${tag} đang ép` + (n ? ` — thử lại ${n}/${MAX_RETRY}` : ''));
      r = await request(u);
      if (r === 'OK') { await saveResult(u, 'OK', `ép lúc ${fmt(new Date())}`); log(`${tag} ÉP OK${n ? ` sau ${n} lần thử lại` : ''}: ${u}`); break; }
      if (r === 'SKIP') { await saveResult(u, 'SKIP', 'không thuộc property'); log(`${tag} BỎ QUA: ${u}`); break; }
      if (r === 'ROBOT') {
        status('⚠️ Google hiện ô "Tôi không phải robot" — hãy bấm ô đó trong tab GSC, rồi bấm Bắt đầu lại');
        log('DỪNG: gặp ô "Tôi không phải robot"');
        alert('Google hiện ô "Tôi không phải robot". Bạn bấm ô đó trong tab Search Console, rồi bấm Bắt đầu lại.');
        return;
      }
      if (n >= MAX_RETRY) {
        await saveResult(u, 'FAIL', `${MAX_RETRY} lần thử lại vẫn chưa được (${r})`);
        log(`${tag} CHƯA ĐƯỢC sau ${MAX_RETRY} lần thử lại (${r}): ${u}`);
        if (r === 'QUOTA') { quotaStop = true; log('=== Hết lượt ép trong ngày — link cần ép còn lại để chạy lại hôm sau'); }
        break;
      }
      n++;
      log(`  chưa được (${r}) — thử lại ${n}/${MAX_RETRY}`);
      await sleep(r === 'REJECTED' ? WAIT_REJECTED : WAIT_RETRY);
    }
  }
  if (!stopFlag) { status('✅ Xong. Bấm "Sao chép kết quả" rồi dán vào chat cho Claude.'); log('=== XONG'); }
}

// ---------- Nút bấm ----------
$('batdau').onclick = async () => {
  stopFlag = false;
  $('batdau').disabled = true; $('dung').disabled = false;
  try { await main(); }
  catch (e) { status('⚠️ ' + e.message); log('DỪNG: ' + e.message); }
  $('batdau').disabled = false; $('dung').disabled = true;
  if (stopFlag) status('Đã dừng. Bấm Bắt đầu để chạy tiếp, link đã xong sẽ không làm lại.');
};
$('dung').onclick = () => { stopFlag = true; status('Đang dừng sau bước hiện tại...'); };
$('xoa').onclick = async () => {
  if (!confirm('Xoá hết kết quả đã lưu?')) return;
  results = {}; await chrome.storage.local.set({ results }); showCount();
};
$('saochep').onclick = async () => {
  const rows = Object.entries(results).map(([u, r]) => `${u}\t${r.kq}\t${r.note}`);
  await navigator.clipboard.writeText(['URL\tKết quả\tGhi chú', ...rows].join('\n'));
  status(`Đã sao chép ${rows.length} dòng — dán vào chat cho Claude.`);
};
document.title += ' ' + chrome.runtime.getManifest().version;
log('Phiên bản tiện ích: ' + chrome.runtime.getManifest().version);
chrome.storage.local.get('results').then((s) => { results = s.results || {}; showCount(); });
